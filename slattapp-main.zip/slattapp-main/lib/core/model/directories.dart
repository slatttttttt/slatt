import 'dart:io';

typedef Directories = ({
  Directory baseDir,
  Directory workingDir,
  Directory tempDir
});
