package com.hiddify.hiddify.constant

enum class Status {
    Stopped,
    Starting,
    Started,
    Stopping,
}