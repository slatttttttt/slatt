package com.hiddify.hiddify.constant

object ServiceMode {
    const val NORMAL = "proxy"
    const val VPN = "vpn"
}