package com.hiddify.hiddify.constant

object Action {
    const val SERVICE = "com.hiddify.app.SERVICE"
    const val SERVICE_CLOSE = "com.hiddify.app.SERVICE_CLOSE"
    const val SERVICE_RELOAD = "com.hiddify.app.sfa.SERVICE_RELOAD"
}